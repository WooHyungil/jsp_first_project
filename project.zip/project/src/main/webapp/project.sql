CREATE DATABASE adventure;
USE adventure;

-- check(0) : 미승인
-- check(1) : 승인

CREATE TABLE member (
	member_id VARCHAR(20),
	member_pw VARCHAR(20),
	member_name VARCHAR(20),
    member_email VARCHAR(100),
    member_phoneNumber VARCHAR(100),
    member_Address VARCHAR(100),
	member_check INT		
);

CREATE TABLE board(
	board_number int auto_increment primary key,
	member_id VARCHAR(20),
    member_name VARCHAR(20),
    member_email VARCHAR(100),
    board_subject VARCHAR(100),
    board_content VARCHAR(100),
    board_date date
) auto_increment = 100;



INSERT INTO board VALUES(null, 'qwer', '홍길동', "qwer@qwer.com", "제목", "내용", curdate());
INSERT INTO board VALUES(null, 'qwer', '김나래', "qwer@qwer.com", "제목", "내용", curdate());

INSERT INTO member VALUES('qwer', '1234', '홍길동', "qwer@qwer.com", "010-1234-1234", "안성", 0);
INSERT INTO member VALUES('abcd', '1234', '김나래', "asdf@asdf.com", "010-2345-3456", "보개", 0);

SELECT * FROM member;
SELECT * FROM board;


SELECT 
    m.member_id,
    m.member_pw,
    b.member_name,
    m.member_email,
    m.member_phoneNumber,
    m.member_Address,
    m.member_check,
    b.board_number,
    b.board_subject,
    b.board_content,
    b.board_date
FROM 
    member m
JOIN 
    board b
ON 
    m.member_id = b.member_id;


DROP table member;
DROP table boardList;